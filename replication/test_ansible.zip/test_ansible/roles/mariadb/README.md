# Mariadb

本文档是 mariadb 集群角色的使用说明.

## 前置条件

1. 需要预先约定 {{ app_home }} 目录, 并在目标机上建立 {{ app_home }} 目录.
2. 创建用户和组, 配置 {{ app_home }}/mariadb 权限为 0770. 用户需要 sudo 权限.
3. 主控机免密访问目标机.

## 角色变量

角色变量, vars/main.yml

``` yaml
# 一般不需要修改
# 静态文件/目录压缩包, 用于部署任务中
static_files_zip: "mariadb.zip"
# 服务的安装目录
service_home: "{{ app_home }}/mariadb"
# 服务的 docker-compose.yml 文件路径
service_docker_compose_file: "{{ service_home }}/docker-compose.yml"
# 服务名, 用于 docker-compose.yml 中的服务名
service_name: mariadb

```

角色的 defaults/main.yml

``` yaml
# 一般不需要修改
# 默认的, mariadb 的 tcp 端口
mariadb_tcp_port: "3306"
```

环境相关的, 易变的变量放置在 inventory-{{env}} 目录中的 mariadb-cluster.yml . {{ evn }} 定义见下表.

| env 名称 | 含义       |
| -------- | ---------- |
| dev      | 开发环境   |
| prod     | 主生产环境 |
| bak-prod | 备生产环境 |

以 inventory-dev/mariadb-cluster.yml 为例说明各变量含义.

``` yaml
all:
  children:
    mariadb:
      # 所有主机
      hosts:
        # 别名
        n1.mariadb.nfcos:
          # 用于 ssh 的 ip
          ansible_ssh_host: 192.168.43.43
        n2.mariadb.nfcos:
          ansible_ssh_host: 192.168.43.44
        n3.mariadb.nfcos:
          ansible_ssh_host: 192.168.43.45

      # 组变量
      vars:
        # mariadb 的 tcp 端口
        mariadb_tcp_port: "3306"
        # mariadb 集群的 boot 节点. 用于第一次建立集群.
        mariadb_boot_node: n1.mariadb.nfcos
        # mariadb 节点的数据存放目录
        mariadb_data_home: /app/midserv/mariadb
        # mariadb data目录的路径
        mariadb_data_path: "{{ mariadb_data_home }}/data"
        # mariadb log 目录的路径
        mariadb_log_path: "{{ mariadb_data_home }}/log"
        # mariadb backup 目录的路径
        mariadb_backup_path: "{{ mariadb_data_home }}/backup"
        # mariadb 的镜像
        mariadb_docker_image: harbor.iibu.com/base/mariadb:10.3
        # mariadb 的配置文件
        mariadb_mdb_cnf_file: "{{ service_home }}/config/cluster.cnf"
        # mariadb 配置内使用的变量
        # innodb 缓冲池大小，根据实际物理机内存，推荐为可用内存的60-80%，内存越大比例可以越高
        # 当前设置为 60%
        mariadb_innodb_buffer_pool_size: "{{ ansible_memory_mb.real.total * 6 // 10}}"
        # mariadb 配置内 garela 集群的配置: 同步线程数
        mariadb_wsrep_slave_threads: "{{ ansible_processor_vcpus }}"
        # mariadb 配置内 garela 集群的配置: 集群名称
        mariadb_wsrep_cluster_name: "maria_cluster"

        # mariadb 的 root 用户密码
        mariadb_root_password: root123


```

## 依赖项

依赖的全局变量, 一般设置在 inventory/all_vars.yml 内.

``` yaml
all:
  vars:
    # 环境的标识.
    # 约定:
    #  dev_GT - 开发环境
    #  prod_LC - 主生产环境
    #  bak-prod - 备生产环境
    environment_flag: dev_GT
    # 角色部署目录的父目录
    app_home: /app/midserv
    # 如果 ${USER} 不是目标机的 ssh 用户, 则通过下方变量指定
    ansible_ssh_user: mdb_user
```

## Playbook 样例

该角色的 playbook 例子 pb-mdb-cluster.yml:

```yaml
- hosts: mariadb
  # 必须要收集目标机的信息
  gather_facts: yes
  roles:
    - mariadb-cluster
```

### 开发环境

在开发环境中, 由于需要用户预先创建 {{ app_home }}目录, 所以先创建初始化剧本 pb-dev-init.yaml

``` yaml
- hosts: all
  gather_facts: no
  tasks:
  - name: 创建根目录
    file:
      path: "{{ app_home }}"
      state: directory
    tags:
      - init
      - deploy

```

然后, 使用该剧本创建初始化目录.

``` shell
ansible-playbook -i inventory-dev pb-dev-init.yaml
```

其他使用方法同生产环境. 注意: 开发环境的 inventory 目录为 inventory-dev.

### 生产环境

在生产环境中, {{ app_home }} 目录创建以及权限设置都由主机工程师完成.

剧本使用方法:

``` shell
# 初始化. 初始化需要提升权限, -K 参数表示输入 sudo 密码
ansible-playbook -i inventory-prod pb-mdb-cluster.yml -t init -K
# 部署
ansible-playbook -i inventory-prod pb-mdb-cluster.yml -t deploy
# 启动服务
ansible-playbook -i inventory-prod pb-mdb-cluster.yml -t start
# 检查端口
ansible-playbook -i inventory-prod pb-mdb-cluster.yml -t check
# 停止服务
ansible-playbook -i inventory-prod pb-mdb-cluster.yml -t stop
```

## License

BSD

## Author Information

姓名: 王志军

邮箱: wangzhijun@fmsh.com.cn
