# mariadb_repl readme

1. init
ansible-playbook -i ../inventory pb_mariadb_repl.yml -t init,updateconf -K

1. deploy
ansible-playbook -i ../inventory pb_mariadb_repl.yml -t deploy

1. update config
ansible-playbook -i ../inventory pb_mariadb_repl.yml -t updateconf -K

1. start,check
ansible-playbook -i ../inventory pb_mariadb_repl.yml -t start,check

1. stop
ansible-playbook -i ../inventory pb_mariadb_repl.yml -t stop

1. cleanall
ansible-playbook -i ../inventory pb_mariadb_repl.yml -t cleanall -K -e dangerous_to_remove_data=1

1. 查看配置
ansible mariadb -i ../inventory -m shell -a 'cat /app/midserv/mariadb_repl/config/cluster.cnf'
