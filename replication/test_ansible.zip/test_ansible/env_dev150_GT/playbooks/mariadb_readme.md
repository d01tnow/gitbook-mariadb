# mariadb readme

1. init
ansible-playbook -i ../inventory pb_mariadb.yml -t init,updateconf -K

1. deploy
ansible-playbook -i ../inventory pb_mariadb.yml -t deploy

1. update config
ansible-playbook -i ../inventory pb_mariadb.yml -t updateconf -K

1. start,check
ansible-playbook -i ../inventory pb_mariadb.yml -t start,check

1. stop
ansible-playbook -i ../inventory pb_mariadb.yml -t stop

1. cleanall
ansible-playbook -i ../inventory pb_mariadb.yml -t cleanall -K -e dangerous_to_remove_data=1

1. 查看配置
ansible mariadb -i ../inventory -m shell -a 'cat /app/midserv/mariadb/config/cluster.cnf'

1. 配置 wsrep gtid 相关变量
ansible-playbook -i ../inventory pb_mariadb_config_wsrep_gtid.yml -t config_gtid -e mdb_grp=mariadb -e config_gtid_enabled=1

1. 检查 wsrep gtid 相关变量
ansible-playbook -i ../inventory pb_mariadb_config_wsrep_gtid.yml -t check_gtid -e mdb_grp=mariadb
